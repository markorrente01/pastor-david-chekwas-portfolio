
import { useRef } from "react";
import { AboutTransition } from "./AboutTransition";
import { HomeIntro } from "./HomeIntro";
import { HeroContent } from "./HeroContent";
import { HeroPortrait } from "./HeroPortrait";
import { useHomeHeroAnimations } from "../../hooks/useHomeHeroAnimations";

export function HomeHero() {
  const heroRef = useRef<HTMLElement>(null);
  const portraitRef = useRef<HTMLImageElement>(null);
  const cursorRef = useRef<HTMLDivElement>(null);
  const cursorRingRef = useRef<HTMLDivElement>(null);

  useHomeHeroAnimations({
    heroRef,
    portraitRef,
    cursorRef,
    cursorRingRef,
  });

  return (
    <section
      ref={heroRef}
      className="relative isolate overflow-hidden bg-brand-ink text-brand-white md:h-[calc(100svh-5rem)] md:min-h-[680px]"
    >
      <HomeIntro />

      <div className="pointer-events-none absolute inset-0 opacity-[0.08] [background-image:linear-gradient(rgba(255,255,255,.16)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.16)_1px,transparent_1px)] [background-size:90px_90px]" />

      <div className="pointer-events-none absolute -right-40 top-0 size-[550px] rounded-full bg-brand-gold/10 blur-[130px]" />

      <div className="hero-content relative z-10 flex min-h-[calc(100svh-5rem)] flex-col justify-center py-16 md:h-full md:min-h-0 md:py-12">
        <div className="mx-auto grid w-full max-w-[1440px] items-center gap-12 px-5 sm:px-8 lg:grid-cols-[1.1fr_.9fr] lg:gap-8 lg:px-12">
          <HeroContent />
          <HeroPortrait imageRef={portraitRef} />
        </div>
      </div>

      <AboutTransition />

      <div
        ref={cursorRef}
        className="pointer-events-none fixed left-0 top-0 z-[100] hidden size-1.5 rounded-full bg-brand-gold lg:block"
        aria-hidden="true"
      />

      <div
        ref={cursorRingRef}
        className="pointer-events-none fixed left-0 top-0 z-[99] hidden size-9 rounded-full border border-brand-gold/60 lg:block"
        aria-hidden="true"
      />
    </section>
  );
}
