import { useEffect } from "react";
import type { RefObject } from "react";
import { gsap } from "../../../shared/animations/gsap";

interface HomeHeroAnimationRefs {
  heroRef: RefObject<HTMLElement | null>;
  portraitRef: RefObject<HTMLImageElement | null>;
  cursorRef: RefObject<HTMLDivElement | null>;
  cursorRingRef: RefObject<HTMLDivElement | null>;
}

export function useHomeHeroAnimations({
  heroRef,
  portraitRef,
  cursorRef,
  cursorRingRef,
}: HomeHeroAnimationRefs) {
  useEffect(() => {
    const hero = heroRef.current;
    const portrait = portraitRef.current;
    const cursor = cursorRef.current;
    const cursorRing = cursorRingRef.current;

    if (!hero || !portrait) return;

    let handlePointerMove: ((event: PointerEvent) => void) | undefined;
    let handlePointerOver: ((event: PointerEvent) => void) | undefined;
    let handlePointerOut: ((event: PointerEvent) => void) | undefined;

    const context = gsap.context(() => {
      const media = gsap.matchMedia();

      media.add(
        {
          desktop: "(min-width: 1024px) and (prefers-reduced-motion: no-preference)",
          tablet: "(min-width: 768px) and (max-width: 1023px) and (prefers-reduced-motion: no-preference)",
          mobile: "(max-width: 767px) and (prefers-reduced-motion: no-preference)",
          reduced: "(prefers-reduced-motion: reduce)",
        },
        (matchContext) => {
          const conditions = matchContext.conditions as {
            desktop: boolean;
            tablet: boolean;
            mobile: boolean;
            reduced: boolean;
          };

          if (conditions.reduced) {
            gsap.set(".home-intro", { autoAlpha: 0, display: "none" });
            gsap.set(
              ".hero-eyebrow, .hero-title-line, .hero-copy, .hero-actions, .hero-portrait-frame",
              { clearProps: "all" },
            );
            gsap.set(".home-about-panel", { clearProps: "transform" });
            return;
          }

          const intro = gsap.timeline({
            defaults: { ease: "power3.out" },
          });

          intro
            .fromTo(
              ".home-intro-kicker",
              { y: 18, opacity: 0 },
              { y: 0, opacity: 1, duration: 0.7 },
            )
            .fromTo(
              ".home-intro-name",
              { yPercent: 110, opacity: 0, scale: 0.96 },
              { yPercent: 0, opacity: 1, scale: 1, duration: 1.1 },
              "-=0.25",
            )
            .fromTo(
              ".home-intro-tagline, .home-intro-line",
              { y: 15, opacity: 0 },
              { y: 0, opacity: 1, duration: 0.65, stagger: 0.12 },
              "-=0.35",
            )
            .to(".home-intro-content", {
              y: -35,
              opacity: 0,
              duration: 0.45,
              delay: 0.45,
            })
            .to(
              ".home-intro",
              {
                clipPath: "inset(0 0 100% 0)",
                duration: 1.05,
                ease: "power4.inOut",
              },
              "-=0.1",
            )
            .set(".home-intro", { display: "none" });

          const entrance = gsap.timeline({
            defaults: { ease: "power3.out" },
            delay: 0.15,
          });

          entrance
            .fromTo(
              ".hero-eyebrow",
              { y: 25, opacity: 0 },
              { y: 0, opacity: 1, duration: 0.8 },
            )
            .fromTo(
              ".hero-title-line",
              { yPercent: 110, rotate: 3 },
              { yPercent: 0, rotate: 0, duration: 1.1, stagger: 0.14 },
              "-=0.3",
            )
            .fromTo(
              ".hero-copy, .hero-actions",
              { y: 25, opacity: 0 },
              { y: 0, opacity: 1, duration: 0.8, stagger: 0.15 },
              "-=0.45",
            )
            .fromTo(
              ".hero-portrait-frame",
              {
                clipPath: "inset(15% 15% 15% 15%)",
                scale: 1.12,
                opacity: 0,
              },
              {
                clipPath: "inset(0% 0% 0% 0%)",
                scale: 1,
                opacity: 1,
                duration: 1.5,
              },
              "-=1.1",
            );

          if (conditions.desktop && cursor && cursorRing) {
            gsap.set([cursor, cursorRing], {
              xPercent: -50,
              yPercent: -50,
            });

            const cursorX = gsap.quickTo(cursor, "x", {
              duration: 0.15,
              ease: "power3",
            });
            const cursorY = gsap.quickTo(cursor, "y", {
              duration: 0.15,
              ease: "power3",
            });
            const ringX = gsap.quickTo(cursorRing, "x", {
              duration: 0.45,
              ease: "power3",
            });
            const ringY = gsap.quickTo(cursorRing, "y", {
              duration: 0.45,
              ease: "power3",
            });
            const portraitX = gsap.quickTo(portrait, "x", {
              duration: 0.7,
              ease: "power3",
            });
            const portraitY = gsap.quickTo(portrait, "y", {
              duration: 0.7,
              ease: "power3",
            });

            handlePointerMove = (event) => {
              cursorX(event.clientX);
              cursorY(event.clientY);
              ringX(event.clientX);
              ringY(event.clientY);

              const bounds = hero.getBoundingClientRect();
              const relativeX =
                (event.clientX - bounds.left) / bounds.width - 0.5;
              const relativeY =
                (event.clientY - bounds.top) / bounds.height - 0.5;

              portraitX(relativeX * -18);
              portraitY(relativeY * -18);
            };

            handlePointerOver = (event) => {
              if ((event.target as HTMLElement).closest("a, button")) {
                gsap.to(cursorRing, {
                  scale: 1.8,
                  backgroundColor: "rgba(214,168,75,0.08)",
                  duration: 0.3,
                });
              }
            };

            handlePointerOut = (event) => {
              if ((event.target as HTMLElement).closest("a, button")) {
                gsap.to(cursorRing, {
                  scale: 1,
                  backgroundColor: "transparent",
                  duration: 0.3,
                });
              }
            };

            window.addEventListener("pointermove", handlePointerMove);
            hero.addEventListener("pointerover", handlePointerOver);
            hero.addEventListener("pointerout", handlePointerOut);
          }

          if (conditions.desktop) {
            gsap.set(".home-about-panel", { yPercent: 100 });

            const transition = gsap.timeline({
              scrollTrigger: {
                trigger: hero,
                start: "top top",
                end: "+=130%",
                scrub: 1,
                pin: true,
                pinSpacing: true,
                anticipatePin: 1,
                invalidateOnRefresh: true,
              },
            });

            transition
              .to(
                ".hero-content",
                {
                  y: -90,
                  scale: 0.88,
                  opacity: 0.2,
                  duration: 1,
                  ease: "power2.inOut",
                },
                0,
              )
              .to(
                ".hero-portrait-frame",
                {
                  scale: 0.9,
                  opacity: 0.15,
                  duration: 1,
                  ease: "power2.inOut",
                },
                0,
              )
              .to(
                ".home-about-panel",
                { yPercent: 0, duration: 1, ease: "none" },
                0,
              )
              .fromTo(
                ".about-transition-content",
                { y: 80, opacity: 0 },
                {
                  y: 0,
                  opacity: 1,
                  duration: 0.55,
                  ease: "power3.out",
                },
                0.4,
              );
          }

          return () => {
            if (handlePointerMove) {
              window.removeEventListener("pointermove", handlePointerMove);
            }
            if (handlePointerOver) {
              hero.removeEventListener("pointerover", handlePointerOver);
            }
            if (handlePointerOut) {
              hero.removeEventListener("pointerout", handlePointerOut);
            }
          };
        },
      );

      return () => media.revert();
    }, hero);

    return () => context.revert();
  }, [heroRef, portraitRef, cursorRef, cursorRingRef]);
}
